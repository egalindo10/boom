/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Stars, Environment, Box, Text, Center } from '@react-three/drei';
import * as THREE from 'three';

const Butterfly = ({ position, color, speed = 1, delay = 0 }: { position: [number, number, number]; color: string; speed?: number; delay?: number }) => {
  const ref = useRef<THREE.Group>(null);
  const wingRefL = useRef<THREE.Mesh>(null);
  const wingRefR = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ref.current && wingRefL.current && wingRefR.current) {
      const t = state.clock.getElapsedTime() * speed + delay;
      
      // Wing flapping
      const flap = Math.sin(t * 10) * 0.8;
      wingRefL.current.rotation.z = flap;
      wingRefR.current.rotation.z = -flap;
      
      // Floating movement
      ref.current.position.y = position[1] + Math.sin(t * 2) * 0.5;
      ref.current.position.x = position[0] + Math.cos(t * 0.5) * 1;
      ref.current.rotation.y = Math.sin(t * 0.3) * 0.5;
    }
  });

  return (
    <group ref={ref} position={position}>
      {/* Left Wing */}
      <mesh ref={wingRefL} position={[-0.2, 0, 0]}>
        <planeGeometry args={[0.4, 0.4]} />
        <meshStandardMaterial color={color} side={THREE.DoubleSide} transparent opacity={0.8} />
      </mesh>
      {/* Right Wing */}
      <mesh ref={wingRefR} position={[0.2, 0, 0]}>
        <planeGeometry args={[0.4, 0.4]} />
        <meshStandardMaterial color={color} side={THREE.DoubleSide} transparent opacity={0.8} />
      </mesh>
    </group>
  );
};

const FloatingBook = ({ position, rotation, color }: { position: [number, number, number]; rotation: [number, number, number]; color: string }) => {
  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.getElapsedTime();
      ref.current.position.y = position[1] + Math.sin(t + position[0]) * 0.3;
      ref.current.rotation.x = rotation[0] + Math.sin(t * 0.5) * 0.1;
      ref.current.rotation.z = rotation[2] + Math.cos(t * 0.3) * 0.1;
    }
  });

  return (
    <group ref={ref} position={position} rotation={rotation}>
      {/* Book Cover */}
      <Box args={[1, 1.4, 0.1]} position={[0, 0, 0]}>
        <meshStandardMaterial color={color} roughness={0.8} />
      </Box>
      {/* Pages */}
      <Box args={[0.9, 1.3, 0.08]} position={[0, 0, 0.02]}>
        <meshStandardMaterial color="#f5f5f0" roughness={0.5} />
      </Box>
    </group>
  );
};

export const BoomHeroScene: React.FC = () => {
  const butterflies = useMemo(() => [
    { position: [-4, 2, -5] as [number, number, number], color: "#FFD700", speed: 1.2, delay: 0 },
    { position: [4, -1, -4] as [number, number, number], color: "#FFD700", speed: 0.8, delay: 2 },
    { position: [-2, -3, -6] as [number, number, number], color: "#FFD700", speed: 1.5, delay: 4 },
    { position: [2, 3, -3] as [number, number, number], color: "#FFD700", speed: 1.0, delay: 1 },
    { position: [0, 0, -8] as [number, number, number], color: "#FFD700", speed: 0.5, delay: 3 },
  ], []);

  const books = useMemo(() => [
    { position: [-3, 1, -2] as [number, number, number], rotation: [0.5, 0.2, 0.3] as [number, number, number], color: "#5A5A40" },
    { position: [3, -2, -3] as [number, number, number], rotation: [-0.3, -0.4, -0.2] as [number, number, number], color: "#A67C52" },
    { position: [-1, -2, -5] as [number, number, number], rotation: [0.2, 0.1, -0.4] as [number, number, number], color: "#1A1A1A" },
  ], []);

  return (
    <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 8], fov: 45 }}>
        <ambientLight intensity={0.8} />
        <pointLight position={[10, 10, 10]} intensity={1.5} color="#C5A059" />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#A67C52" />
        
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
          {books.map((book, i) => (
            <FloatingBook key={i} {...book} />
          ))}
        </Float>
        
        {butterflies.map((bf, i) => (
          <Butterfly key={i} {...bf} />
        ))}

        <Environment preset="sunset" />
      </Canvas>
    </div>
  );
};

export const AuthorScene: React.FC = () => {
  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <ambientLight intensity={1} />
        <spotLight position={[5, 5, 5]} angle={0.3} penumbra={1} intensity={2} color="#C5A059" />
        <Environment preset="studio" />
        
        <Float rotationIntensity={0.4} floatIntensity={0.2} speed={1}>
          <Center>
            <Text
              font="https://fonts.gstatic.com/s/cormorantgaramond/v16/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYpHtK.woff"
              fontSize={0.5}
              color="#5A5A40"
              anchorX="center"
              anchorY="middle"
            >
              MACONDO
            </Text>
          </Center>
        </Float>
      </Canvas>
    </div>
  );
}
